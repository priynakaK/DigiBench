import { inject, Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { UserAuthService } from './services/userAuth.service';
import { ConsoleLoggerService } from './services/console-loger.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  private logService=inject(ConsoleLoggerService);

  constructor(private authService: UserAuthService, private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {

    if (this.authService.isAuthenticated()) {
      this.logService.log("Inside CanActivate: Authenticated");
      return true;
    } else {
      this.logService.log("Inside CanActivate: Not Authenticated");
      this.router.navigate(['/message'], { queryParams: { message: 'You need to be logged in to access this page.' } });
      return false;
    }
  }
}

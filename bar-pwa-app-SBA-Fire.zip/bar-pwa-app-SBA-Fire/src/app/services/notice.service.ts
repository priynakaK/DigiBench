import { inject, Injectable,  } from '@angular/core';
import {  BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Notice } from '../model/Notice';
import { addDoc, collection, collectionData, CollectionReference, Firestore } from '@angular/fire/firestore';
import { deleteObject, ref, Storage } from '@angular/fire/storage';
import { ConsoleLoggerService } from './console-loger.service';


@Injectable({
  providedIn: 'root'
})
export class NoticeService  {

  private booleanSubject = new BehaviorSubject<boolean>(false);

  private notices$:Observable<Notice[]>;
  private fireStore:Firestore=inject(Firestore);
  private noticeCollection!: CollectionReference<Notice>;
  private storage = inject(Storage);
  private logService=inject(ConsoleLoggerService);

  constructor(){
    this.noticeCollection = collection(this.fireStore, 'notices') as CollectionReference<Notice>;
    this.notices$=this.loadNotices();
  }

  loadNotices(): Observable<Notice[]> {
    return collectionData<Notice>(this.noticeCollection);
  }

  getNoticeByStatus(status:string):Observable<Notice[]>{
    return this.notices$.pipe(
      map(notices => notices.filter(notice=>notice.status===status))
    )
  }

  // TODO implementation is empty
  async addNewNotice(newNotice: Notice) {
    //TODO handle error more gracefully
    try{
      this.logService.log("New Notice : "+ newNotice.status);
      await addDoc(this.noticeCollection, newNotice);
    }catch(E: any){
        this.logService.error("Error at line 30 in member Service : "+E);
    }

  }

  isUploading(){
    this.booleanSubject.next(false);
  }
  isUploaded(){
    this.booleanSubject.next(true);
  }
  isUploadComplete(){
    return this.booleanSubject.asObservable();
  }

  removeFile(fileName:string){
    if (fileName) {
      const storageRef = ref(this.storage, `/notices/${fileName}`);

      // Delete the file from Firebase Storage
      deleteObject(storageRef)
        .then(() => {
          this.logService.log('File deleted successfully');
        })
        .catch((error) => {
          this.logService.error('Error occurred while deleting the file: ', error);
        });
    }
  }
}

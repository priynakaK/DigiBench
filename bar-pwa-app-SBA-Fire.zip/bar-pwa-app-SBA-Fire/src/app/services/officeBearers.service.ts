import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { OfficeBearer } from '../model/OfficeBearer';
import { collectionData, Firestore } from '@angular/fire/firestore';
import { collection } from 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})
export class OfficeBearerService {

  private officeBearers$!:Observable<OfficeBearer[]>;
  private fireStore:Firestore=inject(Firestore);

  constructor() {
    this.officeBearers$=this.loadOfficeBearers();
  }
  loadOfficeBearers(): Observable<OfficeBearer[]> {
    const officeBearerCollection=collection(this.fireStore, 'bearers');
    return collectionData<OfficeBearer>(officeBearerCollection);
  }

  getOfficeBearers():Observable<OfficeBearer[]>{
    return this.officeBearers$.pipe(
      map(bearers=>bearers.sort((a,b)=>a.seqNo-b.seqNo)))
  }
}


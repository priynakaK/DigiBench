import { inject, Injectable } from '@angular/core';
import {
  Auth,
  signInWithEmailAndPassword,
  User,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  sendEmailVerification,
} from '@angular/fire/auth';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { ConsoleLoggerService } from './console-loger.service';

@Injectable({
  providedIn: 'root',
})
export class UserAuthService {
  private user!: User | null;
  private auth = inject(Auth);
  private router = inject(Router);
  private logService = inject(ConsoleLoggerService);

  // Observable for authentication status
  private isAuthenticatedSubject = new BehaviorSubject<User | null>(null);
  private authErrorSubject = new BehaviorSubject<string | null>(null); // For holding error messages

  constructor() {
    // Listen to the authentication state changes from Firebase
    onAuthStateChanged(this.auth, (user) => {
      this.user = user;
      this.isAuthenticatedSubject.next(this.user);
    });
  }

  // Send a verification email to the user
  sendVerificationEmail() {
    const user = this.auth.currentUser;
    if (user) {
      sendEmailVerification(user)
        .then(() => {
          console.log('Verification email sent!');
        })
        .catch((error) => {
          console.error('Error sending verification email:', error);
        });
    }
  }

  // Getter for the isAuthenticated observable
  isAuthenticatedUser(): Observable<User | null> {
    return this.isAuthenticatedSubject.asObservable();
  }

  // Getter for the auth error observable
  getAuthError(): Observable<string | null> {
    return this.authErrorSubject.asObservable();
  }

  isAuthenticated(): boolean {
    return this.isAuthenticatedSubject.getValue() !== null;
  }

  logIn(email: string, pwd: string) {
    signInWithEmailAndPassword(this.auth, email, pwd)
      .then((userCredentials) => {
        this.user = userCredentials.user;
        this.isAuthenticatedSubject.next(this.user); // Notify observers of the change
        this.authErrorSubject.next(null); // Clear any previous error
        this.router.navigate(['/user']);
      })
      .catch((error) => {
        this.logService.error('Login Error using Log Service: ', error);
        this.authErrorSubject.next(this.getErrorMessage(error.code)); // Set the error message
      });
  }

  logOut() {
    this.auth.signOut().then(() => {
      this.user = null;
      this.isAuthenticatedSubject.next(this.user); // Notify observers of the change
      this.router.navigate(['/auth']);
    });
  }

  getUserName(): string | null {
    return this.user ? this.user.displayName : null;
  }

  getProfilePictureURL(): string | null {
    return this.user ? this.user.photoURL : null;
  }

  getUserID() {
    return this.user ? this.user.uid : null;
  }

  registerUser(email: string, password: string) {
    return createUserWithEmailAndPassword(this.auth, email, password);
  }

  private getErrorMessage(errorCode: string): string {
    switch (errorCode) {
      case 'auth/user-not-found':
        return 'User not found. Please check your email.';
      case 'auth/wrong-password':
        return 'Incorrect password. Please try again.';
      case 'auth/invalid-email':
        return 'Invalid email format.';
      default:
        return 'Login failed. Please try again.';
    }
  }
}

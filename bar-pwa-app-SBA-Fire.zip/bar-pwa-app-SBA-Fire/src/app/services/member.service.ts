import { inject, Injectable } from '@angular/core';
import {
  addDoc,
  collection,
  collectionData,
  CollectionReference,
  doc,
  docData,
  Firestore,
  updateDoc,
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Member, RegUser } from '../model/members';
import { UserAuthService } from './userAuth.service';
import {
  getDownloadURL,
  ref,
  Storage,
  uploadBytes,
} from '@angular/fire/storage';
import { ConsoleLoggerService } from './console-loger.service';
@Injectable({
  providedIn: 'root',
})
export class MemberService {
  private firestore = inject(Firestore);
  private logService = inject(ConsoleLoggerService);

  private registrationCollection!: CollectionReference;
  authService = inject(UserAuthService);
  private storage = inject(Storage); // Inject Firebase Storage for profile picture upload

  constructor() {
    this.registrationCollection = collection(this.firestore, 'registration');
  }

  //TODO CRUD operations

  /* 1. Create New Member by Admin user only
        Accepts newMember object and returns uses : addDoc(reference, data)
        Add a new document to specified CollectionReference with the given data, assigning it a document ID automatically.
  */
  async createNewMember(newMember: RegUser) {
    //TODO implementation of uploading the Image file to store, get URL, add it to newMember
    // add this newMember to "FireStore/registration" collection
    try {
      await addDoc(this.registrationCollection, newMember).then((docRef) => {
        this.logService.log('new Member Created after Registration: ' + docRef.id );
      });
    } catch (E: any) {
      this.logService.log('Error at : ' + E);
    }
  }
  //---------------------------------------------------------------
  /* 2. Read the ALL members from Firestore collection
   */
  readAllMember(): Observable<Member[]> {
    const memberCollection = collection(this.firestore, 'members');
    return collectionData(memberCollection) as Observable<Member[]>;
  }

  //-------------------------------------------------------------------
  // 3. Read a single member profile from Firestore based on the authUID
  getMemberProfile(authUID: string): Observable<Member> {
    const memberDocRef = doc(this.firestore, `members/${authUID}`);
    return docData(memberDocRef) as Observable<Member>;
  }

  // 4. Update a member profile in Firestore
  async updateMemberProfile(updatedMember: Member) {
    if (updatedMember.authUID) {
      const memberDocRef = doc(
        this.firestore,
        `members/${updatedMember.authUID}`
      );
      try {
        await updateDoc(memberDocRef, { ...updatedMember });
      } catch (error) {
        this.logService.error('Error updating member profile:', error);
      }
    }
  }

  // 5. Upload profile picture to Firebase Storage and get URL
  async uploadProfilePicture(
    file: File,
    authUID: string
  ): Promise<string | null> {
    try {
      const storageRef = ref(this.storage, `profile_pictures/${authUID}`);
      await uploadBytes(storageRef, file);
      const downloadURL = await getDownloadURL(storageRef);
      return downloadURL;
    } catch (error) {
      this.logService.error('Error uploading profile picture:', error);
      return null;
    }
  }

  //---------------------------------------------------------------------
  /* 5. Delete a member */
  deleteMember(ID: string): boolean {
    return false;
  }
}

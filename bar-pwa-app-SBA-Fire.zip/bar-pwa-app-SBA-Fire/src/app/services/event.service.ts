
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { SBAEvents } from '../model/Events';
import { addDoc, collection, collectionData, CollectionReference, Firestore } from '@angular/fire/firestore';
import { deleteObject, ref, Storage } from '@angular/fire/storage';
import { ConsoleLoggerService } from './console-loger.service';

@Injectable({
  providedIn: 'root',
})
export class EventsService {

  private booleanSubject = new BehaviorSubject<boolean>(false);

  private events$!:Observable<SBAEvents[]>;
  private fireStore:Firestore=inject(Firestore);
  private eventCollection: CollectionReference<SBAEvents>;
  private storage = inject(Storage);
  private logService=inject(ConsoleLoggerService);

  constructor(){
    this.eventCollection = collection(this.fireStore, 'events') as CollectionReference<SBAEvents>;
    this.events$=this.loadEvents();
  }


  loadEvents(): Observable<SBAEvents[]> {

    return collectionData<SBAEvents>(this.eventCollection);
  }

  getEventByType(type:string):Observable<SBAEvents[]>{
    return this.events$.pipe(
      map(events => events.filter(event => event.type===type))
    )
  }

  async addNewEvent(newEvent: SBAEvents) {

    //TODO handle error more gracefully
    try{
      await addDoc(this.eventCollection, newEvent);
    }catch(E: any){
        this.logService.error("Error at line 30 in member Service : "+E);
    }
  }

  isUploading(){
    this.booleanSubject.next(false);
  }
  isUploaded(){
    this.booleanSubject.next(true);
  }
  isUploadComplete(){
    return this.booleanSubject.asObservable();
  }

  removeFile(fileName:string, type:string){
    if (fileName) {
      const storageRef = ref(this.storage, `/events/${type}/${fileName}`);

      // Delete the file from Firebase Storage
      deleteObject(storageRef)
        .then(() => {
          this.logService.log('File deleted successfully');
        })
        .catch((error) => {
          this.logService.error('Error occurred while deleting the file: ', error);
        });
    }
  }
}

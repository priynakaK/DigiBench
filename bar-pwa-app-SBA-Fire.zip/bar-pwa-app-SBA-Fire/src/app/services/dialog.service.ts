import { Injectable, Injector, ViewContainerRef } from '@angular/core';
import { MemberDetailDialogComponent } from '../pages/members/member-detail-dialog/member-detail-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class DialogService {

  private viewContainerRef!: ViewContainerRef;

  constructor(private injector: Injector) {}

  setViewContainerRef(viewContainerRef: ViewContainerRef) {
    this.viewContainerRef = viewContainerRef;
  }

  open(data: any) {
    if (this.viewContainerRef) {
      this.viewContainerRef.clear();
      const componentRef = this.viewContainerRef.createComponent(MemberDetailDialogComponent, {
        injector: this.createInjector(data)
      });
      componentRef.onDestroy(() => this.viewContainerRef.clear());
    }
  }

  close() {
    this.viewContainerRef.clear();
  }

  private createInjector(data: any): Injector {
    return Injector.create({
      providers: [
        { provide: 'data', useValue: data }
      ],
      parent: this.injector
    });
  }

}

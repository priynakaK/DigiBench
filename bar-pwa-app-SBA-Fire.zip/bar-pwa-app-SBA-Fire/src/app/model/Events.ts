
import { Timestamp } from 'firebase/firestore';


export interface SBAEvents{
  id?: string,
  title:string,
  description:string,
  type: string,
  date:Timestamp,
  urlList:string
}

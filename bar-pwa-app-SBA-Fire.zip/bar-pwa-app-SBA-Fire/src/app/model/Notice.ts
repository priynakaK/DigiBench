export interface Notice{
  id?: string,
  title:string,
  description:string,
  date:string,
  fileName?: string,
  fileURL?: string,
  status?:string
}

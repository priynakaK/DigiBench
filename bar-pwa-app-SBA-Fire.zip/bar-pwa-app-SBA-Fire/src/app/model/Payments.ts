import { Timestamp } from 'firebase/firestore';

export interface Payments{
  id?:string,
  amount:number,
  date: Timestamp,
  receipt?:string,
  mode?:string
}

export interface UserRoles {
  admin?:boolean;
  activeUser?:boolean;  // user has paid the fees and hence all membership access
  unpaidUser:boolean;  // user account exists but not paid the membership fees so limited access
}

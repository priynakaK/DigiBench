export interface OfficeBearer {
  id?:string;
  salutation?:string;
  name:string;
  post:string;
  education:string;
  exp:string;
  image:string;
  seqNo:number;
}

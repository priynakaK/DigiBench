import { Timestamp } from 'firebase/firestore';

export interface RegUser{
  paymentID: string,
  SBAIdScanCopyURL:string,
  fname:string,
  lname:string,
  email:string,
  mobile:string,
  password:string
}

export interface Member{
  id?: string,
  authUID?:string, // this auth.user.uid connects auth User to Member, serving this as profile of the USER.
  paymentID:string|null,
  fname:string,
  mname?:string,
  lname:string,
  email:string,
  mobile?:string;
  address?:string,
  iconURL?:string|null,
  joinDate:Timestamp,
  qualification?:string,
  practicing_since?: Timestamp,
  gender:string,
  membershipStatus:string, // [active, applied, non-paid]
  membershipExpiryDate: Timestamp,

  // other fields for profile only
  cast?:string,
  category?:string,
  maritalStatus?:string,
  birthDate?:string,
  DateOfPassingLLB?:string,
  barCouncilIDCard:string,
  NameBeforeMarriage?:string,
  homeTown?:string,
  SeniorAdvName?:string,
  aptitude?:string // [Civil, Criminal, Revenue, Co-Operative, Labour, Tax]
  ifGovtRepresent?:string // name of Government organization
  isMemberOfWelfare?:string // YES / NO
}

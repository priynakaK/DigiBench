import { Component, OnInit } from '@angular/core';
import { Member } from '../../../model/members';
import { MemberService } from '../../../services/member.service';
import { FileUploadComponent } from "../../../shared-components/file-upload/file-upload.component";

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [FileUploadComponent],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {

  ngOnInit(): void {
    //TODO
  }

}

import { Component, inject, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { PageTitleComponent } from "../../shared-components/page-title/page-title.component";
import { UserAuthService } from '../../services/userAuth.service';


@Component({
  selector: 'app-user',
  standalone: true,
  imports: [
    CommonModule,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    PageTitleComponent
],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent {

  @Input() user:any;

  isCurrentSelected:boolean=true;
  private router=inject(Router);
  private authService=inject(UserAuthService);

  onClick(){
    this.isCurrentSelected=!this.isCurrentSelected;
  }

  editProfile() {
    this.router.navigate(['edit-profile'])
  }

  logOut() {
    this.authService.logOut();
  }

}

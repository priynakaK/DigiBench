import { Component } from '@angular/core';
import { EventCardComponent } from '../event-card/event-card.component';
import { EventsService } from '../../../services/event.service';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { SBAEvents } from '../../../model/Events';

@Component({
  selector: 'app-event-photo',
  standalone: true,
  imports: [EventCardComponent, CommonModule],
  templateUrl: './event-photo.component.html',
  styleUrl: './event-photo.component.css'
})
export class EventPhotoComponent {
  photos$!:Observable<SBAEvents[]>;
  constructor(private service: EventsService ) { }

  ngOnInit() {
    this.photos$=this.service.getEventByType('photo');
  }
}

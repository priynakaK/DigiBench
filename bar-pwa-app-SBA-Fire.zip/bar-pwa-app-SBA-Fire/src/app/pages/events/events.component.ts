import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { NgClass } from '@angular/common';
import { PageTitleComponent } from '../../shared-components/page-title/page-title.component';

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [
    PageTitleComponent,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    NgClass,
  ],
  templateUrl: './events.component.html',
  styleUrl: './events.component.css',
})
export class EventsComponent {
  isPhotoSelected: boolean = true;
  private router=inject(Router);

  onClick() {
    this.isPhotoSelected = !this.isPhotoSelected;
  }

  addEvent() {
    this.router.navigate(['add-event'])
  }
}

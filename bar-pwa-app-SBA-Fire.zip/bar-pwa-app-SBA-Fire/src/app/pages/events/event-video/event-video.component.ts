import { Component } from '@angular/core';
import { EventCardComponent } from '../event-card/event-card.component';
import { EventsService } from '../../../services/event.service';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { SBAEvents } from '../../../model/Events';

@Component({
  selector: 'app-event-video',
  standalone: true,
  imports: [EventCardComponent, CommonModule],
  templateUrl: './event-video.component.html',
  styleUrl: './event-video.component.css'
})
export class EventVideoComponent {
  videos$!:Observable<SBAEvents[]>;
  constructor(private service: EventsService ) { }

  ngOnInit() {
    this.videos$=this.service.getEventByType('video');
  }
}

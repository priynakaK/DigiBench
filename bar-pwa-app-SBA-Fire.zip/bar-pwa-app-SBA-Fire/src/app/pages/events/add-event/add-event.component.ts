import {
  Component,
  ElementRef,
  inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ConfirmationDialogComponent } from '../../../shared-components/confirmation-dialog/confirmation-dialog.component';
import { Router } from '@angular/router';
import { EventsService } from '../../../services/event.service';
import { PageTitleComponent } from '../../../shared-components/page-title/page-title.component';
import { SBAEvents } from '../../../model/Events';
import { CommonModule } from '@angular/common';
import { FileUploadComponent } from '../../../shared-components/file-upload/file-upload.component';
import { ConsoleLoggerService } from '../../../services/console-loger.service';

@Component({
  selector: 'app-add-event',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    PageTitleComponent,
    ConfirmationDialogComponent,
    CommonModule,
    FileUploadComponent,
  ],
  templateUrl: './add-event.component.html',
  styleUrl: './add-event.component.css',
})
export class AddEventComponent implements OnInit {
  eventForm!: FormGroup;
  @ViewChild(ConfirmationDialogComponent) dialog!: ConfirmationDialogComponent;
  @ViewChild('video') videoLinkElement!: ElementRef;

  private selectedFile!: string;
  private downloadURL: string = '';
  private type: string = '';
  selectedMedia = '';

  private logService=inject(ConsoleLoggerService);

  constructor(
    private router: Router,
    private eventService: EventsService

  ){ }

  ngOnInit(): void {
    const today = new Date().toISOString().substring(0, 10);

    this.eventForm = new FormGroup({
      title: new FormControl('', [
        Validators.required,
        Validators.maxLength(100),
      ]),
      description: new FormControl('', [
        Validators.required,
        Validators.maxLength(1500),
      ]),
      date: new FormControl(today, [Validators.required]),
      type: new FormControl('', [Validators.required]),
    });
  }

  onSelected(value: string) {
    this.selectedMedia = value;
  }
  getFileAndURL(event: any) {
    this.selectedFile = event.fileName;
    this.downloadURL = event.fileURL;
    this.logService.log('Event FileURL: ' + event.fileURL);
  }
  openConfirmationDialog(): void {
    if (this.dialog) {
      this.dialog.open();
    }
  }

  submitForm(): void {
    if (this.eventForm.valid) {
      const val = this.eventForm.value;
      const newEvent: SBAEvents = {
        title: val.title,
        date: val.date,
        description: val.description,
        type: val.type,
        urlList: this.downloadURL,
      };
      if (this.selectedMedia === 'video') {

        newEvent.urlList = this.videoLinkElement.nativeElement.value;
      }
      this.logService.log('Image array : ' + newEvent.urlList);

      this.eventService.addNewEvent(newEvent);
      this.router.navigate(['/events']);
    }
  }

  isUploaded() {
    return this.eventService.isUploadComplete();
  }
  onSubmit() {
    this.openConfirmationDialog();
  }

  onCancel() {
    // TODO Handle cancellation remove uploaded file. MUST do it
    if (this.selectedFile) {
      this.eventService.removeFile(this.selectedFile, this.type);
    }
    this.router.navigate(['/events']);
  }

  onDialogCancel() {
    //TODO handle dialog cancel here
  }

  hasError(field: string, error: string) {
    const control = this.eventForm.get(field);
    return control?.dirty && control?.hasError(error);
  }


}

import { Component } from '@angular/core';

@Component({
  selector: 'app-copyright-bar',
  standalone: true,
  imports: [],
  templateUrl: './copyright-bar.component.html',
  styleUrl: './copyright-bar.component.css'
})
export class CopyrightBarComponent {

}

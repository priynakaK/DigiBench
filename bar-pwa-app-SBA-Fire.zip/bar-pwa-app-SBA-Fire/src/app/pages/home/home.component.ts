import { Component, inject } from '@angular/core';
import { BuildingComponent } from './building/building.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { OffBearerComponent } from './off-bearer/off-bearer.component';
import { CopyrightBarComponent } from './copyright-bar/copyright-bar.component';
import { ConsoleLoggerService } from '../../services/console-loger.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    BuildingComponent,
    AboutComponent,
    ContactComponent,
    OffBearerComponent,
    CopyrightBarComponent,
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {

  private logService=inject(ConsoleLoggerService);
  scrollToElement($element: HTMLElement): void {
    this.logService.log($element);
    $element.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
      inline: 'nearest',
    });
  }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-building',
  standalone: true,
  imports: [],
  templateUrl: './building.component.html',
  styleUrl: './building.component.css'
})
export class BuildingComponent {

}

import { Component, inject } from '@angular/core';
import { BearerComponent } from './bearer/bearer.component';
import { Observable } from 'rxjs';
import { OfficeBearer } from '../../../model/OfficeBearer';
import { OfficeBearerService } from '../../../services/officeBearers.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-off-bearer',
  standalone: true,
  imports: [BearerComponent, CommonModule],
  templateUrl: './off-bearer.component.html',
  styleUrl: './off-bearer.component.css'
})
export class OffBearerComponent {

  bearers$!:Observable<OfficeBearer[]>;

  private OBservice=inject(OfficeBearerService);

  ngOnInit(){
    this.bearers$=this.OBservice.getOfficeBearers();
  }
}

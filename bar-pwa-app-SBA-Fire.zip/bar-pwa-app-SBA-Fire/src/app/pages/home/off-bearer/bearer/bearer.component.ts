import { Component, Input } from '@angular/core';
import { OfficeBearer } from '../../../../model/OfficeBearer';

@Component({
  selector: 'app-bearer',
  standalone: true,
  imports: [],
  templateUrl: './bearer.component.html',
  styleUrl: './bearer.component.css',
})
export class BearerComponent {
  @Input() bearer!: OfficeBearer;
}

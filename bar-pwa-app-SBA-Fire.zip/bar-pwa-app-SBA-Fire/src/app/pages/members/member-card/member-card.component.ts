import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-member-card',
  standalone: true,
  imports: [],
  templateUrl: './member-card.component.html',
  styleUrl: './member-card.component.css'
})
export class MemberCardComponent {

  @Input() member: any;
  @Output() openDetailDialog = new EventEmitter<any>(); // Emit an event when clicked

  setDefaultImg() {
    this.member.iconURL="/img/person.svg"
  }

  onCardClick() {
    this.openDetailDialog.emit(this.member);
  }
}

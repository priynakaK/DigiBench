import { Component, inject, OnInit, ViewChild } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { PageTitleComponent } from '../../../shared-components/page-title/page-title.component';
import { ConfirmationDialogComponent } from '../../../shared-components/confirmation-dialog/confirmation-dialog.component';
import { Router } from '@angular/router';
import { MemberService } from '../../../services/member.service';
import { Member } from '../../../model/members';
import { CommonModule } from '@angular/common';
import { ConsoleLoggerService } from '../../../services/console-loger.service';

@Component({
  selector: 'app-add-member',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    PageTitleComponent,
    ConfirmationDialogComponent,
    CommonModule,
  ],
  templateUrl: './add-member.component.html',
  styleUrl: './add-member.component.css',
})
export class AddMemberComponent implements OnInit {
  memberForm!: FormGroup;
  @ViewChild(ConfirmationDialogComponent) dialog!: ConfirmationDialogComponent;

  private logService=inject(ConsoleLoggerService);

  constructor(private router: Router, private memberService: MemberService) {}

  ngOnInit(): void {
    const today = new Date().toISOString().substring(0, 10);
    const thisDate = new Date();
    const futureDate = new Date(thisDate.setDate(thisDate.getDate() + 365))
      .toISOString()
      .substring(0, 10); // Format the date as YYYY-MM-DD

    this.memberForm = new FormGroup({
      fname: new FormControl('', [Validators.required, Validators.maxLength(20)]),
      mname: new FormControl('', Validators.maxLength(20)),
      lname: new FormControl('', [Validators.required, Validators.maxLength(20)]),
      email: new FormControl('', [Validators.required, Validators.email, Validators.maxLength(50)]),
      mobile: new FormControl('', Validators.pattern('^([0-9]{10})?$')),
      address: new FormControl('', Validators.maxLength(100)),
      joinDate: new FormControl(today, [Validators.required]),
      qualification: new FormControl('', Validators.maxLength(20)),
      practicing_since: new FormControl('', [Validators.required]),
      gender: new FormControl('', [Validators.required]),
      membershipExpiryDate: new FormControl(futureDate, [Validators.required]),
    });
  }

  openConfirmationDialog(): void {
    if (this.dialog) {
      this.dialog.open();
    }
  }

  // TODO - add details for  membershipExpiryDate, membershipStatus, paymentID
  async submitForm() {
    if (this.memberForm.valid) {
      const val = this.memberForm.value;
      const newMember: Member = {
        paymentID: 'invalid',// TODO remove it latter
        barCouncilIDCard:'invalid',// TODO remove
        fname: val.fname,
        mname: val.mname,
        lname: val.lname,
        email: val.email,
        mobile: val.mobile,
        address: val.address,
        joinDate: val.joinDate,
        qualification: val.qualification,
        practicing_since: val.practicing_since,
        gender: val.gender,
        membershipStatus: 'unpaid',
        membershipExpiryDate: val.membershipExpiryDate
      };
      try {
        //await this.memberService.createNewMember(newMember);
      } catch (E: any) {
        this.logService.error('Error at : ' + E);
      }
      this.router.navigate(['/members']);
    }
  }

  onSubmit() {
    this.openConfirmationDialog();
  }
  onCancel() {
    // Handle cancellation if needed
  }
}

import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { SearchComponent } from '../../shared-components/search/search.component';
import { MemberService } from '../../services/member.service';
import { AlphaSortComponent } from '../../shared-components/alpha-sort/alpha-sort.component';
import { MemberCardComponent } from './member-card/member-card.component';
import { PageTitleComponent } from '../../shared-components/page-title/page-title.component';
import { Observable } from 'rxjs';
import { Member } from '../../model/members';
import { Router, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DialogService } from '../../services/dialog.service';
import { MemberDetailDialogComponent } from "./member-detail-dialog/member-detail-dialog.component";

@Component({
  selector: 'app-members',
  standalone: true,
  imports: [
    SearchComponent,
    AlphaSortComponent,
    MemberCardComponent,
    PageTitleComponent,
    CommonModule,
    RouterOutlet,
    MemberDetailDialogComponent
],
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css'], // Corrected here
})
export class MembersComponent implements OnInit {
  Members$!: Observable<Member[]>;

  selectedMember: Member | null = null; // Keep track of the selected member
  showDialog: boolean = false;  // Show/hide the dialog

  constructor(
    private router: Router,
    private memberService: MemberService,
  ) {}

  ngOnInit() {
    this.reloadMembers();
  }

  reloadMembers() {
    this.Members$ = this.memberService.readAllMember();
  }

  addMembers() {
    this.router.navigate(['add-member']);
  }

  openDetailDialog(member: Member) {
    this.selectedMember = member;
    this.showDialog = true;
  }

  closeDialog() {
    this.showDialog = false;
    this.selectedMember = null;
  }

}

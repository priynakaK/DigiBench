import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import { Member } from '../../../model/members';
import { DialogService } from '../../../services/dialog.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-member-detail-dialog',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './member-detail-dialog.component.html',
  styleUrl: './member-detail-dialog.component.css'
})
export class MemberDetailDialogComponent {
  @Input() member: any;  // Receive the selected member
  @Output() closeDialog = new EventEmitter<void>();  // Emit when closing the dialog

  // Close dialog
  onCloseClick() {
    this.closeDialog.emit();
  }

  setDefaultImg() {
    this.member.iconURL="/img/person.svg"
  }
}

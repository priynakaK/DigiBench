import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { Notice } from '../../../model/Notice';

@Component({
  selector: 'app-notice-card',
  standalone: true,
  imports: [ CommonModule],
  templateUrl: './notice-card.component.html',
  styleUrl: './notice-card.component.css'
})
export class NoticeCardComponent {
  @Input() entry!: Notice;

}

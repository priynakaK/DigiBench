import { Component, inject, OnInit, ViewChild } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import { PageTitleComponent } from '../../../shared-components/page-title/page-title.component';
import { Router } from '@angular/router';
import { NoticeService } from '../../../services/notice.service';
import { ConfirmationDialogComponent } from '../../../shared-components/confirmation-dialog/confirmation-dialog.component';
import { Notice } from '../../../model/Notice';
import { CommonModule } from '@angular/common';
import { FileUploadComponent } from '../../../shared-components/file-upload/file-upload.component';
import { UtilityService } from '../../../services/utility';
import { ConsoleLoggerService } from '../../../services/console-loger.service';

//---------------------Component Starts here
@Component({
  selector: 'app-add-notice',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    PageTitleComponent,
    ConfirmationDialogComponent,
    CommonModule,
    FileUploadComponent
  ],
  templateUrl: './add-notice.component.html',
  styleUrls: ['./add-notice.component.css'],
})
export class AddNoticeComponent implements OnInit {

  @ViewChild(ConfirmationDialogComponent) dialog!: ConfirmationDialogComponent;
  noticeForm!: FormGroup;
  private selectedFile: string = '';
  private downloadURL: string = '';
  private logService=inject(ConsoleLoggerService);

  constructor(private router: Router,  private noticeService: NoticeService) {}

  ngOnInit(): void {
    const today = new Date().toISOString().substring(0, 10);

    this.noticeForm = new FormGroup({
      title: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      description: new FormControl('', [Validators.required, Validators.maxLength(1500)]),
      date: new FormControl(today, [Validators.required]),
      //TODO include fileName and fileURL from file-upload component
    });

  }

  openConfirmationDialog(): void {
    if (this.dialog) {
      this.dialog.open();
    }
  }
  getFileAndURL(event:any){
    this.selectedFile=event.fileName;
    this.downloadURL=event.fileURL;
    this.logService.log("fired Event FileURL: "+event.fileURL);
  }
  submitForm(): void {
    this.logService.log("Notice Form Valid: "+this.noticeForm.valid )
    if (this.noticeForm.valid ) {
      const val = this.noticeForm.value;
      const newNotice: Notice = {
        title: val.title,
        description: val.description,
        date: val.date,
        status: 'current',
        fileName: this.selectedFile || '', // Handle case when no file is selected
        fileURL: this.downloadURL || '', // Handle case when no file is uploaded
      };
      this.logService.log('Notice File: ' + (newNotice.fileName || 'No file selected'));
      this.logService.log('Notice file URL: ' + (newNotice.fileURL || 'No file URL'));
      this.noticeService.addNewNotice(newNotice);
      //TODO here you call the service method to update old Notice to "Archive status"
      //TODO and also remove very old notices from Archive
      this.router.navigate(['/circulars']);
    }
  }

  isUploaded(){
    return this.noticeService.isUploadComplete();
  }

  onSubmit() {
    this.openConfirmationDialog();
  }

  onCancel() {
    // TODO Handle cancellation remove uploaded file. MUST do it
    if(this.selectedFile){
      this.noticeService.removeFile(this.selectedFile);
    }
    this.router.navigate(['/circulars']);
  }

  onDialogCancel(){
    //TODO handle dialog cancel here
  }

  hasError( field: string, error: string ) {
    const control = this.noticeForm.get(field);
    return control?.dirty && control?.hasError(error);
  }

}



import { Component } from '@angular/core';
import { NoticeCardComponent } from '../notice-card/notice-card.component';
import { NoticeService } from '../../../services/notice.service';
import { Observable } from 'rxjs';
import { Notice } from '../../../model/Notice';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-current-circular',
  standalone: true,
  imports: [NoticeCardComponent, CommonModule],
  templateUrl: './current-circular.component.html',
  styleUrl: './current-circular.component.css'
})
export class CurrentCircularComponent {
  currentNotices$!: Observable<Notice[]>;
  constructor(private service: NoticeService) {}

  ngOnInit() {
      this.currentNotices$=this.service.getNoticeByStatus('current');
  }

}

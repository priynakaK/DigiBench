import { Component } from '@angular/core';
import { NoticeService } from '../../../services/notice.service';
import { NoticeCardComponent } from '../notice-card/notice-card.component';
import { Observable } from 'rxjs';
import { Notice } from '../../../model/Notice';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-archived-circular',
  standalone: true,
  imports: [NoticeCardComponent, CommonModule],
  templateUrl: './archived-circular.component.html',
  styleUrl: './archived-circular.component.css'
})
export class ArchivedCircularComponent {
  archivedNotices$!: Observable<Notice[]>;
  constructor(private service: NoticeService) {}

  ngOnInit() {
      this.archivedNotices$=this.service.getNoticeByStatus('archived');
  }

}

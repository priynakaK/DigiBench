import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { FileUploadComponent } from "../../shared-components/file-upload/file-upload.component";
import { ConsoleLoggerService } from '../../services/console-loger.service';

@Component({
  selector: 'app-register-user',
  standalone: true,
  imports: [FileUploadComponent],
  templateUrl: './register-user.component.html',
  styleUrl: './register-user.component.css'
})
export class RegisterUserComponent {

  private router=inject(Router);
  selectedFile: string='';
  downloadURL: string='';
  private logService=inject(ConsoleLoggerService);

  registerNewUser(paymentID:string) {
    if(paymentID && this.downloadURL){
      const newUser = { paymentID: paymentID, IdURL: this.downloadURL };
      this.router.navigate(['/add-new-user'], { state: { user: newUser } });
    }else{
      alert("Please input payment ID and Upload the ID Card")
    }
  }

  getFileAndURL(event: any) {
    this.selectedFile = event.fileName;
    this.downloadURL = event.fileURL;
    this.logService.log('Event FileURL: ' + event.fileURL);
  }

}

import { Component, inject, Input, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationDialogComponent } from '../../../shared-components/confirmation-dialog/confirmation-dialog.component';
import { PageTitleComponent } from '../../../shared-components/page-title/page-title.component';
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { MemberService } from '../../../services/member.service';
import { Member, RegUser } from '../../../model/members';
import { CommonModule } from '@angular/common';
import { ConsoleLoggerService } from '../../../services/console-loger.service';
import { UserAuthService } from '../../../services/userAuth.service';
import { updateProfile } from '@angular/fire/auth';

@Component({
  selector: 'app-add-user',
  standalone: true,
  imports: [
    ConfirmationDialogComponent,
    PageTitleComponent,
    CommonModule,
    ReactiveFormsModule,
  ],
  templateUrl: './add-user.component.html',
  styleUrl: './add-user.component.css',
})
export class AddUserComponent implements OnInit {
  memberFormStage1!: FormGroup;

  @ViewChild(ConfirmationDialogComponent) dialog!: ConfirmationDialogComponent;

  private router = inject(Router);
  private logService = inject(ConsoleLoggerService);
  private memberService = inject(MemberService);
  private authService = inject(UserAuthService);

  paymentID!: string;
  barCouncilIdCardURL!: string;
  showPassword: boolean = false; // Variable to toggle password visibility

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.paymentID = history.state.user.paymentID;
    this.barCouncilIdCardURL = history.state.user.IdURL;

    if (this.paymentID) {
      const today = new Date().toISOString().substring(0, 10);
      const thisDate = new Date();
      const futureDate = new Date(thisDate.setDate(thisDate.getDate() + 365))
        .toISOString()
        .substring(0, 10); // Format the date as YYYY-MM-DD

      this.memberFormStage1 = new FormGroup({
        fname: new FormControl('', [
          Validators.required,
          Validators.maxLength(20),
        ]),
        lname: new FormControl('', [
          Validators.required,
          Validators.maxLength(20),
        ]),
        email: new FormControl('', [
          Validators.required,
          Validators.email,
          Validators.maxLength(50),
        ]),
        mobile: new FormControl('',[
          Validators.required,
          Validators.pattern('^([0-9]{10})?$')
        ]),
        password: new FormControl('', [
          Validators.required,
          Validators.maxLength(15),
          Validators.pattern(
            '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{6,}$'
          ),
        ]), // Password must be at least 6 characters, include upper, lower, digit, and special character
      });
    } else {
      // if no payment ID provided somehow...
      alert('No payment ID available');
      this.router.navigate(['/register']);
    }
  }

  openConfirmationDialog(): void {
    if (this.dialog) {
      this.dialog.open();
    }
  }

  async submitForm() {
    if (this.memberFormStage1.valid) {
      const stage1Data = this.memberFormStage1.value;
      const newRegMember: RegUser = {
        paymentID: this.paymentID,
        SBAIdScanCopyURL: this.barCouncilIdCardURL,
        fname: stage1Data.fname,
        lname: stage1Data.lname,
        email: stage1Data.email,
        mobile: stage1Data.mobile,
        password: stage1Data.password
      };
      try {
        await this.authService.registerUser(newRegMember.email, newRegMember.password)
        .then((userCredentials)=>{
          // Save additional user details to Firestore/member
          //TODO use ID from User to new member
          updateProfile(userCredentials?.user, {
              // update profile here
              displayName: newRegMember.fname+' '+newRegMember.lname,
              photoURL: "/img/person.svg",
          }).then(()=>{
            // TODO what to do when profile updated
          }).catch((error)=>{
            this.logService.error(error);
          })
          this.memberService.createNewMember(newRegMember);
          // send the verification email to user who is already logged in.
          this.authService.sendVerificationEmail();
          alert('Sign-up successful! Please check your email for verification.');
        })
        //this.router.navigate(['/message', message]); // TODO replace the alert with message page
      } catch (Error: any) {
        this.logService.error('Error during sign-up:', Error);
      }
    }
  }

  onSubmit() {
    this.openConfirmationDialog();
  }

  onCancel() {
    // Handle cancellation if needed
  }

  // Method to toggle the password visibility
  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }
}

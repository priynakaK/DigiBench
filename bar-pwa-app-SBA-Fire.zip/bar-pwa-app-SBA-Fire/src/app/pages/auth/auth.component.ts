import { Component, inject, OnInit } from '@angular/core';
import { UserAuthService } from '../../services/userAuth.service';
import { LoginComponent } from "../../shared-components/login/login.component";
import { UserComponent } from "../user/user.component";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-auth',
  standalone: true,
  imports: [LoginComponent, UserComponent, CommonModule],
  templateUrl: './auth.component.html',
  styleUrl: './auth.component.css'
})
export class AuthComponent implements OnInit{
  isAuthenticated:boolean=false;
  userName: string | null = null;
  user:any;

  private authService = inject(UserAuthService);

  ngOnInit(): void {
    // Subscribe to the isAuthenticated observable
    this.authService.isAuthenticatedUser().subscribe((user) => {
      this.isAuthenticated = !!user; // Boolean indicating if a user is authenticated
      this.userName = this.authService.getUserName(); // Get the username if available
      this.user=user;
    });
  }

  handleLogin(data: { email: string, pwd: string }) {
    // Call the login function from UserAuthService when login form is submitted
    this.authService.logIn(data.email, data.pwd);
  }

  getUserName(): string | null {
    return this.userName; // Return the current user name
  }

  getUser(){
    return this.user;
  }

}

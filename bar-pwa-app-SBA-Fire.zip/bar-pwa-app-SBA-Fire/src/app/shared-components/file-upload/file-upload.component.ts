import { CommonModule } from '@angular/common';
import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { deleteObject, getDownloadURL, ref, Storage, uploadBytesResumable } from '@angular/fire/storage';
import { NoticeService } from '../../services/notice.service';
import { UtilityService } from '../../services/utility';
import { ConsoleLoggerService } from '../../services/console-loger.service';



@Component({
  selector: 'app-file-upload',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './file-upload.component.html',
  styleUrl: './file-upload.component.css',
})
export class FileUploadComponent {

  noticeService=inject(NoticeService);
  private logService=inject(ConsoleLoggerService);
  storage = inject(Storage);
  // for making file names unique on storage
  private randomString!:string;
  utilService=inject(UtilityService);

  @Input() message: string = ''; // TODO modify
  @Input() requiredFileType!: string;  // File type input (PDF, JPEG, etc.)
  @Input() location:string = 'temp';

  @Output() fileNameAndURL = new EventEmitter;

  fileName!: string;
  fileURL!:string;
  file!: File | null;
  uploadProgress!: number | null;
  uploadError: string='';


  allowedFileTypes = ['pdf', 'jpeg', 'jpg', 'gif', 'png']; // Allowed file types


  onFileSelected(event: any) {
    // reset previous state if any
    this.uploadError='';
    this.uploadProgress=0;
    this.file=null;
    this.fileName=this.fileURL='';
    this.randomString=this.utilService.generateRandomString(4);

    // get the file
    if (event.target.files && event.target.files.length > 0) {
        this.file = event.target.files[0];
        const fileExtension = this.file?.name.split('.').pop()?.toLowerCase();
        if (!this.allowedFileTypes.includes(fileExtension!)) {
          this.uploadError = `Invalid file type. Allowed types: ${this.allowedFileTypes.join(', ')}`;
          this.fileName = '';
          return;
        }
        if (this.file) {
          this.fileName = this.randomString +'-'+ this.file.name;
          // TODO implement upload here
          const fileSizeMB = this.file.size / (1024 * 1024); // Convert bytes to MB
          if (fileSizeMB > 5) {
            this.uploadError = 'File size exceeds 5MB limit. Please select a smaller file.';
            this.fileName='';
            this.fileURL='';
          }
          else{
            this.noticeService.isUploading();
            const storageRef = ref(this.storage, `/${this.location}/${this.fileName}`);
            const uploadTask = uploadBytesResumable(
              storageRef,
              this.file
            );
            uploadTask.on(
              'state_changed',
              (snapshot) => {
                const progress =
                  (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                this.uploadProgress = progress;
                this.noticeService.isUploading();
                this.logService.log("Upload Progress: ",+ progress)
              },
              (error) => {
                this.uploadError =
                  'Error occurred during file upload: ' + error.message;
              },
              () => {
                  getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
                  this.fileURL = downloadURL;
                  this.noticeService.isUploaded();
                  this.logService.log("Uploaded File: " + downloadURL)
                  //emitting the fileName and fileURL after upload is complete
                  this.fileNameAndURL.emit({fileName:this.fileName, fileURL:this.fileURL})
                });
              }
            );
          }
        }
    }
  }
  cancelUpload() {
    if (this.fileName) {
      const storageRef = ref(this.storage, `/${this.location}/${this.fileName}`);

      // Delete the file from Firebase Storage
      deleteObject(storageRef)
        .then(() => {
          this.logService.log('File deleted successfully');
          this.fileName = ''; // Reset file name
          this.fileURL = ''; // Reset file URL
          this.uploadProgress = 0; // Reset progress bar
          this.noticeService.isUploaded(); // Notify that the upload was canceled
          this.fileNameAndURL.emit({fileName:'', fileURL:''})
        })
        .catch((error) => {
          this.logService.error('Error occurred while deleting the file: ', error);
          this.uploadError = 'Error occurred while deleting the file: ' + error.message;
        });
    }
  }
}

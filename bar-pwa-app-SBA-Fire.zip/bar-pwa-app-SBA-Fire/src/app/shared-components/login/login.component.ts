import { CommonModule } from '@angular/common';
import { Component, EventEmitter, inject, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserAuthService } from '../../services/userAuth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent implements OnInit  {

  loginForm: FormGroup;
  router=inject(Router);
  authService = inject(UserAuthService);

  authError: string | null = null;

  showPassword: boolean = false;  // Variable to toggle password visibility

  // Output event to send email and password object to parent
  @Output() loginData: EventEmitter<{ email: string, pwd: string }> = new EventEmitter();

  constructor(private fb: FormBuilder) {
    // Initializing form controls with validation
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      pwd: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  ngOnInit() {
    // Subscribe to the auth error observable to display errors
    this.authService.getAuthError().subscribe((error) => {
      this.authError = error;
    });
  }

  // This method will emit the login form data to the parent component
  onLogin() {
    if (this.loginForm.valid) {
      const email = this.loginForm.get('email')?.value;
      const pwd = this.loginForm.get('pwd')?.value;
      this.loginData.emit({ email, pwd });
    }
  }
  onApplyMembership(){
    this.router.navigate(['/register']);
  }

  // Method to toggle the password visibility
  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

}

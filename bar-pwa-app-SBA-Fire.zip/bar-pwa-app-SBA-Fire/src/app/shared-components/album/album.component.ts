import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-album',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './album.component.html',
  styleUrl: './album.component.css'
})
export class AlbumComponent implements OnInit {


  @Input() mediaURL!:string;
  @Input() mediaType!:string;

  safeMediaURL: SafeResourceUrl | null = null;

  constructor(private sanitizer: DomSanitizer) {}

  ngOnInit(): void {
    if(this.mediaType==='video'){
      this.safeMediaURL=this.getEmbedURL(this.mediaURL);
    }
  }


  setDefaultImg() {
    this.mediaURL="/img/person.svg"
  }

  // Method to transform the YouTube URL into an embeddable URL
  getEmbedURL(videoURL: string): SafeResourceUrl {
    let videoId = videoURL.split('v=')[1];
    const ampersandPosition = videoId ? videoId.indexOf('&') : -1;
    if (ampersandPosition !== -1) {
      videoId = videoId.substring(0, ampersandPosition);
    }
    const embedURL = `https://www.youtube.com/embed/${videoId}`;
    // Mark the URL as safe
    return this.sanitizer.bypassSecurityTrustResourceUrl(embedURL);
  }

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-alpha-sort',
  standalone: true,
  imports: [],
  templateUrl: './alpha-sort.component.html',
  styleUrl: './alpha-sort.component.css'
})
export class AlphaSortComponent {

}

import {
  ApplicationConfig,
  provideZoneChangeDetection,
  isDevMode,
} from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { provideServiceWorker } from '@angular/service-worker';
import { initializeApp, provideFirebaseApp } from '@angular/fire/app';
import { connectAuthEmulator, getAuth, provideAuth } from '@angular/fire/auth';
import { clearIndexedDbPersistence, connectFirestoreEmulator, enableIndexedDbPersistence, enablePersistentCacheIndexAutoCreation, getFirestore, memoryLocalCache, provideFirestore } from '@angular/fire/firestore';
import { connectFunctionsEmulator, getFunctions, provideFunctions } from '@angular/fire/functions';
import { connectStorageEmulator, getStorage, provideStorage } from '@angular/fire/storage';
import { environment } from '../environments/environment';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(withFetch()),
    provideServiceWorker('ngsw-worker.js', {
      enabled: !isDevMode(),
      registrationStrategy: 'registerWhenStable:30000',
    }),

    // FireStore related
    provideFirebaseApp(() => initializeApp(environment.firebase )),

    provideAuth(() => {
      const auth=getAuth();
      connectAuthEmulator(auth, 'http://localhost:9099');
      return auth;
    }),

    provideFirestore(() => {
      const firestore = getFirestore();
      connectFirestoreEmulator(firestore, 'localhost', 8080);
      clearIndexedDbPersistence(firestore);
      enableIndexedDbPersistence(firestore);
      return firestore;
    }),
    provideFunctions(() => {
      const fireFunction=getFunctions();
      connectFunctionsEmulator(fireFunction,'localhost',5001);
      return fireFunction;

    }),
    provideStorage(() => {
      const FireStorage = getStorage();
      connectStorageEmulator(FireStorage, 'localhost', 9199)
      return FireStorage;
    }),


    //----------


    provideAnimationsAsync(),
  ],
};

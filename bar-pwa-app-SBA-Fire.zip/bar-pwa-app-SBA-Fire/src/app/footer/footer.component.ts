import { Component, inject, OnInit, OnDestroy } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { UserAuthService } from '../services/userAuth.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, CommonModule],
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit, OnDestroy {

  isAuthenticated: boolean = false;
  //userRole!:string;
  profilePicture: string | null = '';
  private unsubscribe$ = new Subject<void>(); // to handle un-subscription

  authService = inject(UserAuthService);
  router = inject(Router);  // Inject the Router service

  ngOnInit(): void {
    // Subscribe to the isAuthenticated observable
    this.authService.isAuthenticatedUser()
      .pipe(takeUntil(this.unsubscribe$)) // Ensures cleanup when component is destroyed
      .subscribe((user) => {
        this.isAuthenticated = !!user;

        this.profilePicture = this.isAuthenticated ? this.authService.getProfilePictureURL() || '/svg/user.svg' : '/svg/user.svg';

        // Redirect to the "user" page if authenticated
        if (this.isAuthenticated) {
          this.router.navigate(['/user']);
        }
      });

  }

  setDefaultImg() {
    this.profilePicture = "/svg/user.svg";
  }

  ngOnDestroy(): void {
    // Unsubscribe to avoid memory leaks
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }

  // Handle click on the User Icon
  onUserIconClick() {
    if (this.isAuthenticated) {
      //TODO check for admin user and redirect to /admin
      // else Navigate to the user page if authenticated

      this.router.navigate(['/user']);

    } else {
      // Navigate to the auth page if not authenticated
      this.router.navigate(['/auth']);
    }
  }

}

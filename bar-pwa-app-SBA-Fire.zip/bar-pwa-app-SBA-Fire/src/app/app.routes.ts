import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { MembersComponent } from './pages/members/members.component';
import { CircularsComponent } from './pages/circulars/circulars.component';
import { EventsComponent } from './pages/events/events.component';
import { PaymentsComponent } from './pages/payments/payments.component';
import { CurrentCircularComponent } from './pages/circulars/current-circular/current-circular.component';
import { ArchivedCircularComponent } from './pages/circulars/archived-circular/archived-circular.component';
import { EventVideoComponent } from './pages/events/event-video/event-video.component';
import { EventPhotoComponent } from './pages/events/event-photo/event-photo.component';
import { AddMemberComponent } from './pages/members/add-member/add-member.component';
import { AddNoticeComponent } from './pages/circulars/add-notice/add-notice.component';
import { AddEventComponent } from './pages/events/add-event/add-event.component';
import { AuthComponent } from './pages/auth/auth.component';
import { UserComponent } from './pages/user/user.component';
import { ProfileComponent } from './pages/user/profile/profile.component';
import { SubscriptionComponent } from './pages/user/subscription/subscription.component';
import { EditProfileComponent } from './pages/user/profile/edit-profile/edit-profile.component';
import { RegisterUserComponent } from './pages/register-user/register-user.component';
import { AddUserComponent } from './pages/register-user/add-user/add-user.component';
import { AuthGuard } from './auth.guard';
import { MessageComponent } from './pages/message/message.component';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'members', component: MembersComponent },
  // { path: 'add-member', component: AddMemberComponent },
  {
    path: 'circulars',
    component: CircularsComponent, canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'current', pathMatch: 'full' },
      {
        path: 'current', // child route path
        component: CurrentCircularComponent, canActivate: [AuthGuard],// current route component that the router renders
      },
      {
        path: 'archived',
        component: ArchivedCircularComponent, canActivate: [AuthGuard],// archive child route component that the router renders
      },
    ],
  },
  // { path: 'add-notice', component: AddNoticeComponent },
  {
    path: 'events',
    component: EventsComponent,canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'photo', pathMatch: 'full' },
      {
        path: 'photo', // child route path
        component: EventPhotoComponent, canActivate: [AuthGuard],// photo route component that the router renders
      },
      {
        path: 'video',
        component: EventVideoComponent, canActivate: [AuthGuard],// video child route component that the router renders
      },
    ],
  },
  // { path: 'add-event', component: AddEventComponent },
  { path: 'payments', component: PaymentsComponent },
  {
    path: 'user',
    component: UserComponent,
    children: [
      { path: '', redirectTo: 'profile', pathMatch: 'full' },
      {
        path: 'profile', // child route path
        component: ProfileComponent, // User profile route component that the router renders
      },
      {
        path: 'subscription',
        component: SubscriptionComponent, // User subscription child route component that the router renders
      },
    ],
  },
  { path: 'message', component: MessageComponent },
  { path: 'edit-profile', component: EditProfileComponent , canActivate: [AuthGuard]},
  { path: 'auth', component: AuthComponent },
  { path: 'register', component: RegisterUserComponent },// User profile route component that the router renders
  { path: 'add-new-user', component: AddUserComponent },
  { path: '**', redirectTo: '/home' },
];

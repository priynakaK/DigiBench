// Import the functions you need from the SDKs you need

//import { initializeApp } from "firebase/app";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration

export const environment = {

  production: true,
  useEmulators: false,

  firebase : {
    apiKey: "AIzaSyAWM-ClK5lpy2bgravT2wypdQYIcbd63Wg",
    authDomain: "sba-fire-2dc80.firebaseapp.com",
    projectId: "sba-fire-2dc80",
    storageBucket: "sba-fire-2dc80.appspot.com",
    messagingSenderId: "585832790812",
    appId: "1:585832790812:web:a93ad9aa42a186531b18d9"
  },

  api: {
    // createUser: "http://localhost:5001/fir-course-recording-c7f3e/us-central1/createUser"
  }

};

// Initialize Firebase
//const app = initializeApp(firebaseConfig);

